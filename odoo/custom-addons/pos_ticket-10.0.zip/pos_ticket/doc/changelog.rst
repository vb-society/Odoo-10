Changelog
=========

`10.0.1.2`
----------
- t-extend="Chrome" div changed to company logo

